package dev.ngspace.hudder.variables.data;

import static dev.ngspace.hudder.api.variableregistry.VariableTypes.BOOLEAN;
import static dev.ngspace.hudder.api.variableregistry.VariableTypes.NUMBER;
import static dev.ngspace.hudder.api.variableregistry.VariableTypes.OBJECT;
import static dev.ngspace.hudder.api.variableregistry.VariableTypes.STRING;

import dev.ngspace.hudder.variables.HudderBuiltInVariables;
import dev.ngspace.hudder.variables.advanced.Misc;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.screens.ChatScreen;
import net.minecraft.client.gui.screens.dialog.DialogScreen;
import net.minecraft.client.gui.screens.inventory.ContainerScreen;
import net.minecraft.client.gui.screens.inventory.CraftingScreen;
import net.minecraft.client.gui.screens.inventory.CreativeModeInventoryScreen;
import net.minecraft.client.gui.screens.inventory.InventoryScreen;

public class ClientData extends HudderBuiltInVariables {
	static Minecraft ins;
	
	public static void registerVariables() {
		ins = Minecraft.getInstance();
		registerInputVariables();
		registerScreenVariables();
		registerScreenTypeVariables();

		// Camera state
		register(_->ins.gameRenderer.mainCamera().entity() != ins.player, BOOLEAN, "camera_detached");
		
		// Resource packs
		register(_->ins.getResourcePackRepository().getSelectedPacks().stream()
				.filter(pack->!pack.isRequired())
				.map(t -> t.getTitle().getString())
				.toList(), OBJECT, "selectedresourcepacks");
		register(_->ins.getResourcePackRepository().getSelectedPacks().stream()
				.map(t -> t.getTitle().getString())
				.toList(), OBJECT, "selectedresourcepacks_unfiltered");
		register(_->FabricLoader.getInstance().getAllMods().stream()
				.map(mod-> mod.getMetadata().getId() + ":" + mod.getMetadata().getVersion())
				.toList(), OBJECT, "mods_list");
	}

	private static void registerInputVariables() {
		// Mouse buttons
		register(_->ins.mouseHandler.isLeftPressed(), BOOLEAN, "mouse_left");
		register(_->ins.mouseHandler.isMiddlePressed(), BOOLEAN, "mouse_middle");
		register(_->ins.mouseHandler.isRightPressed(), BOOLEAN, "mouse_right");

		// Clicks per second
		register(_->Misc.getLeftCPS() + Misc.getRightCPS(), NUMBER, "cps");
		register(_->Misc.getLeftCPS(), NUMBER, "cps_left");
		register(_->Misc.getRightCPS(), NUMBER, "cps_right");
	}

	private static void registerScreenVariables() {
		// Window / GUI
		register(_->ins.getWindow().getGuiScaledWidth(), NUMBER, "width");
		register(_->ins.getWindow().getGuiScaledHeight(), NUMBER, "height");
		register(_->ins.getWindow().getGuiScale(), NUMBER, "guiscale");

		// Open GUI
		register(_->Misc.getScreenType(ins.gui.screen()), STRING, "openguitype");

		register(_->(ins.gui.screen() == null) ? null : ins.gui.screen().getTitle().getString(), STRING, "openguititle");

		// HUD / debug
		register(_->ins.gui.hud.isHidden(), BOOLEAN, "hudhidden");
		register(_->ins.getDebugOverlay().showDebugScreen(), BOOLEAN, "showdebug");
		register(_->ins.debugEntries.isOverlayVisible(), BOOLEAN, "f3enabled");
	}
	
	private static void registerScreenTypeVariables() {
		register(_->ins.gui.screen() != null, BOOLEAN, "isguiopen");
		register(_->ins.gui.screen() instanceof ContainerScreen, BOOLEAN, "ischestopen");
		register(_->ins.gui.screen() instanceof CraftingScreen, BOOLEAN, "iscraftingtableopen");
		register(_->ins.gui.screen() instanceof ChatScreen, BOOLEAN, "ischatopen");
		register(_->ins.gui.screen() instanceof DialogScreen<?>, BOOLEAN, "isdialogopen");
		register(_->ins.gui.screen() instanceof InventoryScreen
		        || ins.gui.screen() instanceof CreativeModeInventoryScreen, BOOLEAN, "isinventoryopen");
		register(_->ins.options.keyPlayerList.isDown()
				&& (!ins.isLocalServer() || ins.player.connection.getListedOnlinePlayers().size() > 1),
				BOOLEAN, "is_player_list_shown");
	}
}
