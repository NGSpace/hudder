package dev.ngspace.hudder.uielements;

import com.mojang.datafixers.util.Pair;

import dev.ngspace.hudder.main.HudderRenderer;
import dev.ngspace.hudder.mixin.InGameHudAccessor;
import net.minecraft.client.DeltaTracker;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.Hud;
import net.minecraft.client.gui.contextualbar.ContextualBar;

/**
 * This element is a merging of all builtin GUI elements (Status bars) 
 * with the goal of allowing the creation of a custom
 * game hud without forcing the user to reimplement every single UI Element themselves
 */
public class GameHudElement extends AUIElement {
	
	protected static Minecraft mc = Minecraft.getInstance();
	public enum GuiType {
		STATUS_BARS,
		EXP_AND_MOUNT_BAR,
		HOTBAR,
		ITEM_TOOLTIP;
	}
	
	public final int x;
	public final int y;
	public final GuiType type;
	
	public GameHudElement(int x, int y, GuiType type) {
		this.x = x;
		this.y = y;
		this.type = type;
	}

	@Override public void renderElement(GuiGraphicsExtractor context, HudderRenderer renderer, DeltaTracker delta) {
		try {
			InGameHudAccessor acchud = (InGameHudAccessor) (mc.gui.hud);
			float scaledWidth = context.guiWidth();
	        float scaledHeight = context.guiHeight();
	        var matrixStack = context.pose();
	        matrixStack.pushMatrix();
	        switch (type) {
				case STATUS_BARS:
			        if (mc.gameMode.canHurtPlayer()) {
				        matrixStack.translate(x-scaledWidth/2, y-scaledHeight + 39);
				        acchud.callRenderPlayerHealth(context);
				        acchud.callRenderVehicleHealth(context);
			        }
			        break;
				case EXP_AND_MOUNT_BAR:
					matrixStack.translate(x-scaledWidth/2, y-scaledHeight + 39);
					Hud.ContextualInfo contextualInfo = acchud.callNextContextualInfoState();
					var contextualInfoBar = acchud.contextualInfoBar();
					var contextualInfoBarRenderers = acchud.contextualInfoBarRenderers();
					if (contextualInfo != contextualInfoBar.getFirst()) {
						contextualInfoBar = Pair.of(contextualInfo, contextualInfoBarRenderers.get(contextualInfo).get());
					}

					contextualInfoBar.getSecond().extractBackground(context, delta);
					if (mc.gameMode.hasExperience() && mc.player.experienceLevel > 0) {
						ContextualBar.extractExperienceLevel(context, mc.font, mc.player.experienceLevel);
					}

					contextualInfoBar.getSecond().extractRenderState(context, delta);
					break;
				case HOTBAR:
			        matrixStack.translate(x-scaledWidth/2, y-scaledHeight);
			        acchud.callRenderHotbarAndDecorations(context, delta);
					break;
				case ITEM_TOOLTIP:
					int tooltipy = 44;
					if (mc.gameMode.canHurtPlayer()) tooltipy += 14;
			        matrixStack.translate(x-scaledWidth/2, tooltipy-scaledHeight+y);
			        acchud.callRenderSelectedItemName(context);
					break;
				default:
					break;
			}
	        matrixStack.popMatrix();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
