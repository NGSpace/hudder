package dev.ngspace.hudder.uielements;

import dev.ngspace.hudder.main.HudderRenderer;
import dev.ngspace.hudder.utils.HudFileUtils;
import net.minecraft.client.DeltaTracker;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.resources.Identifier;

public class TextureVerticesElement extends AUIElement {

	private Identifier id;
	private float[] vertices;
	private float[] textures;
	private boolean triangles;
	
	public TextureVerticesElement(String filename, float[] positionArray, float[] textureArray, boolean triangles) {
		this.id = HudFileUtils.getTexture(filename);
		this.vertices = positionArray;
		this.textures = textureArray;
		this.triangles = triangles;
		if (vertices.length!=textures.length)
			throw new IllegalArgumentException("Texture array and Vertex array are not of the same length!");
		if (!HudFileUtils.imageLoaded(id)) 
			throw new IllegalArgumentException("Image not loaded (Or file is not a valid image): " + filename);
	}
	
	@Override public void renderElement(GuiGraphicsExtractor context, HudderRenderer renderer, DeltaTracker delta) {
		renderer.renderTexturedVertexArray(context, vertices, textures, id, triangles);
	}
	
}
