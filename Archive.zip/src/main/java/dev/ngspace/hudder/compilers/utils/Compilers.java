package dev.ngspace.hudder.compilers.utils;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;

import dev.ngspace.hudder.Hudder;
import dev.ngspace.hudder.compilers.HudPackCompiler;
import dev.ngspace.hudder.compilers.HudderV2Compiler;
import dev.ngspace.hudder.compilers.HudderV3Compiler;
import dev.ngspace.hudder.compilers.JavaScriptCompiler;
import dev.ngspace.hudder.compilers.abstractions.AHudCompiler;

public class Compilers {private Compilers() {}
	
	private static Map<String, AHudCompiler<?>> registeredcompilers = new HashMap<String,AHudCompiler<?>>();
	//Made this to make sure there aren't a fuckton of HudderV2Compiler objects being initalized by accident
	public static final HudderV2Compiler hudderV2Compiler = new HudderV2Compiler();
	
	
	public static void registerDefaultCompilers() {
		registeredcompilers.put("hudder", hudderV2Compiler);
		registeredcompilers.put("js", new JavaScriptCompiler());
		registeredcompilers.put("pack", new HudPackCompiler());
		registeredcompilers.put("hudderv3", new HudderV3Compiler());
	}
	
	public static AHudCompiler<?> getCompilerFromName(String name) throws IllegalArgumentException {
		
		String comp = name.toLowerCase();
		if (registeredcompilers.containsKey(comp)) return registeredcompilers.get(comp);
		
		throw new IllegalArgumentException("Compiler named \"" + name + "\" either does not exist or has not yet been loaded.");
	}
	
	/**
	 * @deprecated use {@code #registerCompiler(String, ATextCompiler)}
	 */
	@Deprecated(since = "9.0.0", forRemoval = true)
	public static void registerCompiler(String name, String classname) {
		try {
			registerCompiler(name,(AHudCompiler<?>) Class.forName(classname).getConstructor().newInstance());
		} catch (ReflectiveOperationException e) {
			e.printStackTrace();
			throw new IllegalArgumentException("Failed to load compiler", e);
		}
	}
	
	public static void registerCompiler(String name, AHudCompiler<?> compiler) {
		registeredcompilers.put(name.toLowerCase(), compiler);
		if (Hudder.config!=null)
			Hudder.config.readAndUpdateConfig();
	}
	
	public static boolean has(String name) {
		return registeredcompilers.get(name.toLowerCase())!=null;
	}

	public static Set<String> keySet() {
		return Set.copyOf(registeredcompilers.keySet());
	}
	
	
}
