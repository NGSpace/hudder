package dev.ngspace.hudder.config;

import dev.ngspace.hudder.config.HudSelectionList.HudEntry;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.ObjectSelectionList;
import net.minecraft.network.chat.Component;

public class HudSelectionList extends ObjectSelectionList<HudEntry>{
	
	
	public HudSelectionList(Minecraft minecraft, int width, int height, int y) {
		super(minecraft, width, height, y, 20);

		addEntry(new HudEntry(Component.literal("rthjrew=erfwgfdgdsgdsfdfzdfsgfdgsfdgsfdgs")));
		addEntry(new HudEntry(Component.literal("rthjrew=erfwgfdgdsgdsfdfzdfsgfdgsfdgsfdgs")));
		addEntry(new HudEntry(Component.literal("rthjrew=erfwgfdgdsgdsfdfzdfsgfdgsfdgsfdgs")));
		addEntry(new HudEntry(Component.literal("rthjrew=erfwgfdgdsgdsfdfzdfsgfdgsfdgsfdgs")));
	}
    
    @Override protected void extractListBackground(GuiGraphicsExtractor guiGraphics) {/* It ugly ;_; */}
    
    @Override
    public int getRowWidth() {
    	return 290;
    }

	public static class HudEntry extends ObjectSelectionList.Entry<HudEntry> {
		
		Component component;
		
		public HudEntry(Component component) {
			this.component = component;
		}

		@Override
		public Component getNarration() {
			return component;
		}

		@Override
		public void extractContent(GuiGraphicsExtractor graphics, int mouseX, int mouseY, boolean hovered, float a) {
			graphics.text(Minecraft.getInstance().font, component, getX(), getY(), 0xFF_FF_FF_FF);
		}
	}
}
