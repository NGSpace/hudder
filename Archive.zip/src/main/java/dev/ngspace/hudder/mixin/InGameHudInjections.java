package dev.ngspace.hudder.mixin;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import dev.ngspace.hudder.Hudder;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.DeltaTracker;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.Hud;

@Environment(EnvType.CLIENT)
@Mixin(Hud.class)
public class InGameHudInjections {
	public boolean shouldNotDraw() {return Hudder.config.removegui()&&Hudder.config.shouldCompile();}
    public boolean shouldNotDrawEffects() {return Hudder.config.removeeffects()&&Hudder.config.shouldCompile();}

	@Inject(method = "extractHotbarAndDecorations", at = @At("HEAD"),cancellable=true)
    public void disableHotbarAndDecorations(GuiGraphicsExtractor context, DeltaTracker tickCounter, CallbackInfo i) {
		if(shouldNotDraw()) {
			i.cancel();
		}
	}

    @Inject(method = "extractEffects", at = @At("HEAD"), cancellable = true)
    public void disableEffectsHud(CallbackInfo ci) {
        if (shouldNotDrawEffects()) {
            ci.cancel();
        }
    }
}
