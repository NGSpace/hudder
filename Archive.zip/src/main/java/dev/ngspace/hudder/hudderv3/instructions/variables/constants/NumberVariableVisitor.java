package dev.ngspace.hudder.hudderv3.instructions.variables.constants;

import dev.ngspace.hudder.compilers.abstractions.AV3Compiler;
import dev.ngspace.hudder.exceptions.CompileException;
import dev.ngspace.hudder.hudderv3.asm.V3MethodWriter;
import dev.ngspace.hudder.hudderv3.instructions.variables.VariableVisitor;

public class NumberVariableVisitor extends VariableVisitor {

	private String value;

	public NumberVariableVisitor(AV3Compiler comp, String value) {
		super(comp);
		this.value = value;
	}

	@Override
	public void visit(V3MethodWriter methodWriter) throws CompileException {
		if (value.startsWith("0x")) {
			methodWriter.loadConstant((double)Integer.parseUnsignedInt(value.substring(2), 16));
		} else if (value.startsWith("#")) {
			methodWriter.loadConstant((double)Integer.parseUnsignedInt(value.substring(1), 16));
		} else {
			methodWriter.loadConstant(Double.parseDouble(value));
		}
	}
	
}
