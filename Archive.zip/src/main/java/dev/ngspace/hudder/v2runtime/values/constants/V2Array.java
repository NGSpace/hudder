package dev.ngspace.hudder.v2runtime.values.constants;

import java.util.ArrayList;
import java.util.List;

import dev.ngspace.hudder.compilers.abstractions.AV2Compiler;
import dev.ngspace.hudder.exceptions.ExecutionException;
import dev.ngspace.hudder.v2runtime.V2Runtime;
import dev.ngspace.hudder.v2runtime.values.AV2Value;

public class V2Array extends AV2Value {

	private AV2Value[] values;

	public V2Array(String[] strings, AV2Compiler compiler, V2Runtime runtime, int line, int charpos, String debugvalue)
			throws ExecutionException {
		super(line, charpos, debugvalue, compiler);
		values = new AV2Value[strings.length];
		for (int i = 0;i<strings.length;i++)
			values[i] = compiler.getV2Value(runtime, strings[i], line, charpos);
	}

	@Override public List<Object> get() throws ExecutionException {
		List<Object> array = new ArrayList<Object>();
		for (int i = 0;i<values.length;i++) array.add(values[i].get());
		return array;
	}
	
	@Override public void setValue(AV2Compiler compiler, Object value) throws ExecutionException {
		throw new ExecutionException("Can't change the value of an array constant", line, charpos);
	}
	
	@Override public boolean isConstant() throws ExecutionException {return false;}
}
