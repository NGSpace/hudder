package dev.ngspace.hudder.v2runtime.runtime_elements;

import dev.ngspace.hudder.compilers.abstractions.AV2Compiler;
import dev.ngspace.hudder.compilers.utils.TextPos;
import dev.ngspace.hudder.config.HudderConfig;
import dev.ngspace.hudder.exceptions.CompileException;
import dev.ngspace.hudder.exceptions.ExecutionException;
import dev.ngspace.hudder.compilers.utils.CompileState;
import dev.ngspace.hudder.v2runtime.V2Runtime;
import dev.ngspace.hudder.v2runtime.values.AV2Value;

public class ForV2RuntimeElement extends AV2RuntimeElement {

	private String variablename;
	private AV2Value condition;
	
	public ForV2RuntimeElement(HudderConfig info, String variablename, String value, String instructions,
			AV2Compiler compiler, V2Runtime parentRuntime, TextPos charPosition, String filename)
					throws CompileException, ExecutionException {
		this.variablename = variablename;
		this.condition = compiler.getV2Value(parentRuntime, value, charPosition.line(), charPosition.column());
		this.nestedRuntimes = new V2Runtime[] {compiler.buildRuntime(info, instructions, new TextPos(charPosition.line(), 1),
				filename, parentRuntime)};
	}
	
	@Override
	public boolean execute(CompileState compileState, StringBuilder builder) throws ExecutionException {
		if (condition.get() instanceof Iterable<?> iterable) {
			for (Object val : iterable) {
				nestedRuntimes[0].putScoped(variablename, val);
				CompileState res = nestedRuntimes[0].execute();
				compileState.combineWithResult(res.toResult(), false);
				if (res.hasReturned) compileState.setReturnValue(res.returnValue);
				if (res.hasBroken) break;
			}
		}
		return true;
	}
}