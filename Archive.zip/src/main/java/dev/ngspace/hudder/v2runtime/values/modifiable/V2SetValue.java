package dev.ngspace.hudder.v2runtime.values.modifiable;

import dev.ngspace.hudder.compilers.abstractions.AV2Compiler;
import dev.ngspace.hudder.exceptions.ExecutionException;
import dev.ngspace.hudder.v2runtime.values.AV2Value;

public class V2SetValue extends AV2Value {
	public AV2Value key;
	public AV2Value v2value;

	public V2SetValue(AV2Value key, AV2Value v2value, AV2Compiler compiler, int line, int charpos, String debugvalue) {
		super(line, charpos, debugvalue,compiler);
		this.key = key;
		this.v2value = v2value;
	}
	@Override public Object get() throws ExecutionException {
		Object value = v2value.get();
		key.setValue(compiler, value);
		return value;
	}
	@Override public void setValue(AV2Compiler compiler, Object value) throws ExecutionException {
		throw new ExecutionException(
				"This error is a bug, please report it, \ndbg inf: \"V2SetValue.setValue(V2Comp,o)\", V2Comp:\""
				+ compiler.getClass().getSimpleName() + "\", o:" + value, line, charpos);
	}
	@Override public boolean isConstant() throws ExecutionException {return v2value.isConstant();}
	
}
