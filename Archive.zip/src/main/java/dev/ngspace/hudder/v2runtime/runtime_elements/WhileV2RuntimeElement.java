package dev.ngspace.hudder.v2runtime.runtime_elements;

import dev.ngspace.hudder.Hudder;
import dev.ngspace.hudder.compilers.abstractions.AV2Compiler;
import dev.ngspace.hudder.compilers.utils.TextPos;
import dev.ngspace.hudder.config.HudderConfig;
import dev.ngspace.hudder.exceptions.CompileException;
import dev.ngspace.hudder.exceptions.ExecutionException;
import dev.ngspace.hudder.compilers.utils.CompileState;
import dev.ngspace.hudder.v2runtime.V2Runtime;
import dev.ngspace.hudder.v2runtime.values.AV2Value;

public class WhileV2RuntimeElement extends AV2RuntimeElement {
	
	private AV2Value condition;
	private TextPos charPosition;

	public WhileV2RuntimeElement(HudderConfig info, String condition, String cmds, AV2Compiler compiler,
			V2Runtime runtime, TextPos charPosition, String filename) throws CompileException, ExecutionException {
		this.charPosition = charPosition;
		this.nestedRuntimes = new V2Runtime[] {compiler.buildRuntime(info, cmds,
				new TextPos(charPosition.line(), 1), filename, runtime)};
		this.condition = compiler.getV2Value(nestedRuntimes[0], condition, charPosition.line(), charPosition.column());
	}
	
	@Override public boolean execute(CompileState meta, StringBuilder builder) throws ExecutionException {
		short s=0;
		while (condition.asBoolean()) {
			if (!Hudder.config.unsafeoperations()) {
				s++;
				if (s==Short.MAX_VALUE)
					throw new ExecutionException("Max while loop reached: " + s, charPosition.line(), charPosition.column());
			}
			CompileState res = nestedRuntimes[0].execute();
			meta.combineWithResult(res.toResult(), false);
			if (res.hasReturned) meta.setReturnValue(res.returnValue);
			if (res.hasBroken) break;
		}
		return true;
	}
}
